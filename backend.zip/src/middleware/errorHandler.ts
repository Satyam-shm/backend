import { ErrorRequestHandler } from "express";
import { MongoServerError } from "mongodb";
import { Error } from "mongoose";
import _ from "lodash";

const errorHandler: ErrorRequestHandler = (error, req, res, next) => {
  if (error instanceof Error.ValidationError) {
    const errors = Object.values(error.errors);
    const errorMessages = _.map(errors, ({ path, message }) => ({ [path]: message }));
    return res.status(400).json({ errors: errorMessages });
  }

  console.log("ERROR", error);
  if (error instanceof MongoServerError && error.code === 11000) {
    const keyName = _.keys(error.keyValue)[0];
    return res.status(500).json({ error: `${keyName} is already exists` });
  }

  if (error.code) {
    return res.status(error.code).json({ error: error.message || error });
  }

  res.status(500).json({ error: error.message || error });
};

export default errorHandler;
