import jwt, { JwtPayload } from "jsonwebtoken";
import config from "../config";
import { NextFunction, Request, Response } from "express";

declare global {
  namespace Express {
    interface Request {
      user?: any; // Add the 'user' property to the Request interface
    }
  }
}

function auth(req: Request, res: Response, next: NextFunction) {
  const authorization = req.headers.authorization;

  // Check if the Authorization header exists and has the expected format
  if (!authorization || !authorization.startsWith("Bearer ")) {
    return res.status(401).send("Access denied");
  }

  // Extract the token
  const token = authorization.split(" ")[1];

  if (!authorization || !token) return res.status(401).send("Access denied");

  try {
    const decoded = jwt.verify(token, config.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).send(error);
  }
}

function admin(req: Request, res: Response, next: NextFunction) {
  const user = req.user;
  if (!user.roles.includes("admin")) {
    return res.status(401).send({
      error:
        "Access denied. You do not have the required administrative privileges to perform this action.",
    });
  }
  next();
}

function corporate(req: Request, res: Response, next: NextFunction) {
  const user = req.user;
  if (!user.roles.includes("corporate")) {
    return res.status(401).send({
      error:
        "Access denied. You do not have the required administrative privileges to perform this action.",
    });
  }
  next();
}

export { auth, admin, corporate };
