import { Request, Response, NextFunction } from "express";
import { PaginateModel, Document, SortOrder } from "mongoose";

import UserModel, { User } from "../models/user";
import generateRandomPassword from "../utils/generateRandomPassword";

async function create(req: Request, res: Response, next: NextFunction) {
  try {
    const { password, hashedPassword } = await generateRandomPassword();
    console.log(password);
    req.body.password = hashedPassword;
    const doc = new UserModel(req.body);
    await doc.save();
    res.status(201).send("Employee created successfully");
  } catch (error) {
    next(error);
  }
}

async function readAll(req: Request, res: Response, next: NextFunction) {
  try {
    // const page = parseInt(req.query.page as string) || 1; // Current page number
    // const limit = parseInt(req.query.limit as string) || 10; // Number of documents per page
    // const sortField = (req.query.sortField as string) || "createdAt"; // Field to sort by
    // const sortOrder = (req.query.sortOrder as string) || "asc"; // Sorting order

    // const skip = (page - 1) * limit; // Number of documents to skip

    // const totalDocuments = await UserModel.countDocuments(); // Total number of documents

    // const totalPages = Math.ceil(totalDocuments / limit); // Total number of pages

    // const sortOptions: { [key: string]: SortOrder | { $meta: "textScore" } } = {
    //   [sortField]: sortOrder === "desc" ? -1 : 1,
    // };
    const documents = await UserModel.paginate();
    res.json(documents);
  } catch (error) {
    next(error);
  }
}

async function readById(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const doc = await UserModel.findById(id);

    if (!doc) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.status(200).json(doc);
  } catch (error) {
    next(error);
  }
}

async function updateById(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const updatedDoc = await UserModel.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true,
    });

    if (!updatedDoc) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.status(200).json(updatedDoc);
  } catch (error) {
    next(error);
  }
}

async function deleteById(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const deletedDoc = await UserModel.findByIdAndDelete(id);

    if (!deletedDoc) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.status(200).json(deletedDoc);
  } catch (error) {
    next(error);
  }
}
export default { create, readById, readAll, deleteById, updateById };
