import { Request, Response, NextFunction } from "express";
import UserModel from "../models/user";
import generateRandomPassword from "../utils/generateRandomPassword";

async function create(req: Request, res: Response, next: NextFunction) {
  try {
    const { password, hashedPassword } = await generateRandomPassword();
    console.log(password);
    req.body.password = hashedPassword;
    const doc = new UserModel(req.body);
    await doc.save();
    res.status(201).send("Company created successfully");
  } catch (error) {
    next(error);
  }
}

// TODO reset password  sending mail failed
async function resetPassword(req: Request, res: Response, next: NextFunction) {
  try {
    const { password, hashedPassword } = await generateRandomPassword();
    console.log(password);
    req.body.password = hashedPassword;
    const doc = new UserModel(req.body);
    await doc.save();
    res.status(201).send("Company created successfully");
  } catch (error) {
    next(error);
  }
}

async function readAll(req: Request, res: Response, next: NextFunction) {
  try {
    const documents = await UserModel.paginate();
    res.status(200).json(documents);
  } catch (error) {
    next(error);
  }
}

async function readById(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const doc = await UserModel.findById(id);

    if (!doc) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.status(200).json(doc);
  } catch (error) {
    next(error);
  }
}

async function updateById(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const user = await UserModel.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true,
    });

    if (!user) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
}

async function deleteById(req: Request, res: Response, next: NextFunction) {
  try {
    const { id } = req.params;
    const user = await UserModel.findByIdAndDelete(id);

    if (!user) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
}
export default { create, readById, readAll, deleteById, updateById };
