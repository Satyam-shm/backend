import { Request, Response, NextFunction } from "express";

import jwt from "jsonwebtoken";

// Config
import config from "../config";

// Utils
import { Error } from "../utils/Error";
import { hashPassword, comparePassword } from "../utils/password";
// Models

import UserModel, { ROLES, User } from "../models/user";

async function login(req: Request, res: Response, next: NextFunction) {
  try {
    const { email, password } = req.body;

    const user = await UserModel.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: "Invalid email or password" });
    }
    const isValidPassword = await comparePassword(password, user.password);

    if (!isValidPassword) {
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const accessToken = jwt.sign({ id: user.id, email, roles: user.roles }, config.JWT_SECRET!, {
      expiresIn: "1h",
    });

    const refreshToken = jwt.sign({ email }, config.JWT_SECRET!, {
      expiresIn: "7d",
    });

    res.json({ accessToken, refreshToken });
  } catch (error) {
    next(error);
  }
}

async function signup(req: Request, res: Response, next: NextFunction) {
  try {
    const { email, name, password, phoneNumber, roles }: User = req.body;

    if (roles.includes(ROLES.ADMIN)) return res.status(400).send("Admin role is not allowed.");

    const existingUser = await UserModel.findOne({ email });

    if (existingUser) throw new Error({ message: "User already exists", code: 409 });

    const hashedPassword = await hashPassword(password);
    const user = new UserModel({ name, email, roles, phoneNumber, password: hashedPassword });
    await user.save();
    res.status(201).send("Successfully register a user");
  } catch (error) {
    next(error);
  }
}

async function refreshToken(req: Request, res: Response, next: NextFunction) {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      return res.status(400).json({ message: "Refresh token not provided" });
    }

    // Verify the refresh token
    jwt.verify(refreshToken, config.JWT_SECRET!, (err: any, decoded: any) => {
      if (err) {
        return res.status(401).json({ message: "Invalid refresh token" });
      }

      // Generate a new access token
      const token = jwt.sign({ email: decoded.email }, config.JWT_SECRET!, {
        expiresIn: "1h",
      });

      res.json({ token });
    });
  } catch (error) {
    next(error);
  }
}

async function changePassword(req: Request, res: Response, next: NextFunction) {
  try {
    const { email, currentPassword, newPassword } = req.body;

    // Find the user by email
    const user = await UserModel.findOne({ email });

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Check if the current password is valid
    const isValidPassword = await comparePassword(currentPassword, user.password);

    if (!isValidPassword) {
      return res.status(401).json({ message: "Invalid current password" });
    }

    // Hash and update the new password
    const hashedPassword = await hashPassword(newPassword);
    user.password = hashedPassword;
    await user.save();

    res.json({ message: "Password updated successfully" });
  } catch (error) {
    next(error);
  }
}

export default { login, refreshToken, signup, changePassword };
