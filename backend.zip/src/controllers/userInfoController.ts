import { Request, Response, NextFunction } from "express";
import UserModel, { APPROVAL_STATUS } from "../models/user";
import { UserInfoModel } from "../models";
import { Error } from "../utils/Error";
import { isValidObjectId } from "mongoose";

async function create(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = req.body.user;

    if (!isValidObjectId(userId)) {
      throw new Error({ message: "Invalid user ID", code: 404 });
    }

    const user = await UserModel.findOne({ _id: userId });

    if (!user) {
      throw new Error({ message: "User not found", code: 404 });
    }

    const userInfo = await UserInfoModel.findOne({ user: userId });

    if (userInfo) {
      throw new Error({ message: "User info already created", code: 409 });
    }

    req.body.approvalStatus = APPROVAL_STATUS.PENDING;
    const doc = await UserInfoModel.create(req.body);
    await doc.save();
    res.status(201).send({ id: doc.id, message: "User Info created successfully" });
  } catch (error) {
    next(error);
  }
}

async function update(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = req.body.user;
    if (userId) {
      if (!isValidObjectId(userId)) {
        throw new Error({ message: "Invalid user ID", code: 404 });
      }

      const user = await UserModel.findOne({ _id: userId });

      if (!user) {
        throw new Error({ message: "User not found", code: 404 });
      }
    }

    const userInfo = await UserInfoModel.findOne({ _id: req.body.id });

    if (!userInfo) {
      throw new Error({ message: "User Info not found", code: 404 });
    }

    //  set the request body
    userInfo.$set(req.body);

    // validate the user info
    await userInfo.validate();

    // update the user info
    await UserInfoModel.updateOne({ _id: userId }, { $set: userInfo });
    await userInfo.save();
    res.status(200).send("User Info updated successfully");
  } catch (error) {
    next(error);
  }
}

export default { create, update };
