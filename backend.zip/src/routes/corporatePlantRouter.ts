import { Router } from "express";
import corporatePlantController from "../controllers/corporatePlantController";
import { auth, admin, corporate } from "../middleware/auth";

const corporateRouter = Router();

corporateRouter.post("/", auth, corporate, corporatePlantController.create);

corporateRouter.get("/", auth, admin, corporatePlantController.readAll);
corporateRouter.get("/:id", corporatePlantController.readById);
corporateRouter.delete("/:id", corporatePlantController.deleteById);

export default corporateRouter;
