import { Router } from "express";
import { auth, corporate } from "../middleware/auth";
import userInfoController from "../controllers/userInfoController";

const userInfoRouter = Router();

userInfoRouter.post("/", auth, corporate, userInfoController.create);
userInfoRouter.put("/", auth, corporate, userInfoController.update);

export default userInfoRouter;
