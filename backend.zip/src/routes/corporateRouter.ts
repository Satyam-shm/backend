import { Router } from "express";
import corporateController from "../controllers/corporateController";
import { auth, admin } from "../middleware/auth";

const corporateRouter = Router();

corporateRouter.post("/", auth, admin, corporateController.create);
corporateRouter.get("/", auth, admin, corporateController.readAll);
corporateRouter.get("/:id", corporateController.readById);
corporateRouter.put("/:id", corporateController.updateById);
corporateRouter.delete("/:id", corporateController.deleteById);

export default corporateRouter;
