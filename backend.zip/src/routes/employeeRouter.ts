import { Router } from "express";
import buyerController from "../controllers/buyerController";
import { admin, auth } from "../middleware/auth";

const buyerRouter = Router();
buyerRouter.use(auth);
buyerRouter.post("/", auth, admin, buyerController.create);
buyerRouter.get("/", auth, buyerController.readAll);
buyerRouter.get("/:id", buyerController.readById);
buyerRouter.put("/:id", buyerController.updateById);
buyerRouter.delete("/:id", buyerController.deleteById);

export default buyerRouter;
