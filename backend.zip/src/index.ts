import app from "./app";
import config from "./config";
import db from "./db";

// mongodb connection
async function init() {
  try {
    await db.connect();
  } catch (error) {
    console.log(error);
  }
}

app.listen(config.port, () => {
  console.log(`${config.name} ${config.version}`);
  console.log(`Listening on ${config.port} with NODE_ENV=${config.nodeEnv}`);
  init();
});
