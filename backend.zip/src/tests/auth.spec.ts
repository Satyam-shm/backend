import request from "supertest";
import app from "../app";
import db from "../db";
import UserModel from "../models/user";
import mongoose from "mongoose";

let userId: string;

beforeAll(async () => {
  await db.connect();
});

describe("should signup the user", () => {
  test("Sign up user", async () => {
    try {
      const payload = {
        firstName: "Mohd",
        lastName: "Saquib",
        email: "ab@gmail.com",
        password: "1234",
        roles: ["employee"],
      };
      const result: any = await request(app).post("/api/auth/signup").send(payload);
      userId = result?._body?._id;
      expect(result.statusCode).toEqual(201);
    } catch (error: any) {
      throw error;
    }
  });

  test("it should login the user", async () => {
    try {
      const payload = {
        email: "ab@gmail.com",
        password: "1234",
      };
      const result: any = await request(app).post("/api/auth/login").send(payload);
      expect(result.statusCode).toEqual(200);
    } catch (error: any) {
      throw error;
    }
  });
});

afterEach(async () => {
  if (userId) {
    await UserModel.findByIdAndDelete(userId);
  }
});

afterAll(async () => {
  await mongoose.connection.close();
});
