import mongoose from "mongoose";

function mongooseCustomError() {
  // Custom error message for required fields
  mongoose.Error.messages.general.required = "{PATH} is required";
  // Custom error message for enum validation
  mongoose.Error.messages.String.enum = "{VALUE} is not a valid value";

  mongoose.Error.messages.String.match = "{VALUE} is not a valid value";

  // {
  //   DocumentNotFoundError: null,
  //   general: {
  //     default: 'Validator failed for path `{PATH}` with value `{VALUE}`',
  //     required: 'Path `{PATH}` is required.'
  //   },
  //   Number: {
  //     min: 'Path `{PATH}` ({VALUE}) is less than minimum allowed value ({MIN}).',
  //     max: 'Path `{PATH}` ({VALUE}) is more than maximum allowed value ({MAX}).',
  //     enum: '`{VALUE}` is not a valid enum value for path `{PATH}`.'
  //   },
  //   Date: {
  //     min: 'Path `{PATH}` ({VALUE}) is before minimum allowed value ({MIN}).',
  //     max: 'Path `{PATH}` ({VALUE}) is after maximum allowed value ({MAX}).'
  //   },
  //   String: {
  //     enum: '`{VALUE}` is not a valid enum value for path `{PATH}`.',
  //     match: 'Path `{PATH}` is invalid ({VALUE}).',
  //     minlength: 'Path `{PATH}` (`{VALUE}`) is shorter than the minimum allowed length ({MINLENGTH}).',
  //     maxlength: 'Path `{PATH}` (`{VALUE}`) is longer than the maximum allowed length ({MAXLENGTH}).'
  //   }
  // }
}

export default mongooseCustomError;
