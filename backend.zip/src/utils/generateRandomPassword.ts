import { hashPassword } from "./password";
async function generateRandomPassword() {
  const password = Math.random().toString(36).substring(2, 10);
  return {
    password,
    hashedPassword: await hashPassword(password),
  };
}

export default generateRandomPassword;
