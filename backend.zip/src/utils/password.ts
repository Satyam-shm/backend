import bcrypt from "bcryptjs";
async function hashPassword(password: string) {
  return bcrypt.hash(password, 12);
}

async function comparePassword(currentPassword: string, password: string) {
  return await bcrypt.compare(currentPassword, password);
}

export { hashPassword, comparePassword };
