import dotenv from "dotenv";
dotenv.config();
import packageJson from "../package.json";

/**
 * Pattern for config is:
 * key: process.env['KEY'] ?? default
 */
const config = {
  version: packageJson.version,
  name: packageJson.name,
  description: packageJson.description,
  nodeEnv: process.env["NODE_ENV"] ?? "development",
  port: process.env["PORT"] ?? 3001,
  ALLOWED_ORIGINS: process.env["ALLOWED_ORIGINS"] ?? "*",
  JWT_SECRET: process.env.JWT_SECRET ?? "",
  MONGO_URI: process.env["MONGO_URI"] ?? "mongodb://localhost:27017/cspl",
};

export default config;
