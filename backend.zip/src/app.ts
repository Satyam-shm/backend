import cors from "cors";
import express from "express";
import helmet from "helmet";
import morgan from "morgan";

// Config
import config from "./config";

// Middlewares
import errorHandler from "./middleware/errorHandler";
import notFound from "./middleware/notFound";

// Routes
// import userRouter from "./routes/userRouter";
import buyerRouter from "./routes/employeeRouter";
import authRouter from "./routes/authRouter";
import corporateRouter from "./routes/corporateRouter";
import corporatePlantRouter from "./routes/corporatePlantRouter";
import userInforRouter from "./routes/userInfoRouter";

const app = express();

// Apply most middleware first
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors({ origin: config.ALLOWED_ORIGINS }));
app.use(helmet());
app.use(morgan("tiny"));

// Apply routes before error handling
app.use("/api/auth", authRouter);
// app.use("/api/users", userRouter);
app.use("/api/employee", buyerRouter);
app.use("/api/corporate", corporateRouter);
app.use("/api/corporate-plant", corporatePlantRouter);
app.use("/api/user-info", userInforRouter);

// Apply error handling last
app.use(notFound);
app.use(errorHandler);

export default app;

// TODO
// 1. LOGGING
// 2. SEPARATE ENV
// 3. OOPS BASED (classes)
// 4. Architecture design document
// 5. Test cases
// 6. Unit Testing
// 7. Integration testing
// 8. End-to-end testing
// 9. Estimatations
// 10. All documents
// 11. Contianer based
// 12. Proper error handling

// 13. Code reviews
// 14. Localization  and internalization in backend
// 15. Chalk (DEV)
// 16. Documentation of the code
