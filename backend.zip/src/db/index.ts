import mongoose, { ConnectOptions } from "mongoose";
import config from "../config";
import mongooseCustomError from "../utils/mongooseCustomError";

const connect = async () => {
  try {
    const connectionOptions = { useNewUrlParser: true, useUnifiedTopology: true } as ConnectOptions;
    const conn = await mongoose.connect(config.MONGO_URI, connectionOptions);

    // Custom error message for required fields
    mongoose.Error.messages.general.required = "{PATH} is required";

    // Custom error message for enum validation
    mongoose.Error.messages.String.enum = "{VALUE} is not a valid role.";

    console.log(`MongoDB connected: ${conn.connection.host}`);
  } catch (err) {
    process.exit(1);
  }
};

const disconnect = async () => {
  try {
    await mongoose.connection.close();
  } catch (err) {
    process.exit(1);
  }
};

export default { connect, disconnect };
