import mongooseCustomError from "../utils/mongooseCustomError";
import SellerModel from "./seller";
import UserInfoModel from "./userInfo";
import UserModel from "./userInfo";

mongooseCustomError();

export { SellerModel, UserInfoModel, UserModel };
