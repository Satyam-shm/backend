import { Schema, SchemaDefinition, Document, PaginateModel, model } from "mongoose";
import { User } from "./user";

export interface UserInfo extends Document {
  user: User; // Reference to the User model
  panNumber: string;
  tanNumber: string;
  approvalStatus: string;
  address: string;
  city: string;
  pinCode: number;
  googleAddressLink: string;
  gstin: string;
}

const UserInfoSchemaDefinition: SchemaDefinition<UserInfo> = {
  user: { type: Schema.Types.ObjectId, ref: "User", required: true },
  panNumber: { type: String, required: true },
  tanNumber: { type: String, required: true },
  address: { type: String, required: true },
  city: { type: String, required: true },
  pinCode: { type: Number, required: true },
  googleAddressLink: { type: String, required: true },
  gstin: { type: String, required: true, match: /^[A-Za-z0-9]{15}$/ },
};

// User Schema
const userInfoSchema = new Schema(UserInfoSchemaDefinition);
userInfoSchema.set("timestamps", true);

// User Model
const UserInfoModel = model<UserInfo, PaginateModel<UserInfo>>("UserInfo", userInfoSchema);

export default UserInfoModel;
