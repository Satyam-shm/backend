import { Schema, SchemaDefinition, Document, PaginateModel, model } from "mongoose";
import { User, UserSchemaDefinition } from "./user";

// Seller Schema Definition
export interface Seller extends User, Document {}

const sellerSchemaDefinition: SchemaDefinition<Seller> = {
  ...UserSchemaDefinition,
};

// Seller Schema
const sellerSchema = new Schema(sellerSchemaDefinition);

// Seller Model
const SellerModel = model<Seller, PaginateModel<Seller>>("Seller", sellerSchema);

export default SellerModel;
