import { Schema, SchemaDefinition, Document, PaginateModel, model } from "mongoose";
import { User, UserSchemaDefinition } from "./user";
// Employee Schema Definition
export interface Employee extends User, Document {
  totalCredits: number;
  usedCredits: number;
  reservedCredits: number;
}

const employeeSchemaDefinition: SchemaDefinition<Employee> = {
  ...UserSchemaDefinition,
  totalCredits: {
    type: Number,
  },
  usedCredits: {
    type: Number,
  },
  reservedCredits: {
    type: Number,
  },
};

// Employee Schema
const employeeSchema = new Schema(employeeSchemaDefinition);

// Employee Model
const BuyerModel = model<Employee, PaginateModel<Employee>>("Employee", employeeSchema);

export default BuyerModel;
