import { Schema, model, PaginateModel, SchemaDefinition, Document } from "mongoose";
import paginate from "mongoose-paginate-v2";

export enum ROLES {
  ADMIN = "admin",
  SUB_ADMIN = "subAdmin",
  CORPORATE = "corporateAdmin",
  EMPLOYEE = "employee",
  CORPORATE_PLANT = "corporatePlant",
  CORPORATE_SUB_ADMIN = "corporateSubAdmin",
  SELLER = "seller",
  SELLER_SUB_ADMIN = "sellerSubAdmin",
}

export enum APPROVAL_STATUS {
  PENDING = "pending",
  REJECTED = "rejected",
  APPROVED = "approved",
}

export interface User extends Document {
  name: string;
  email: string;
  password: string;
  roles: ROLES[];
  verified: boolean;
  phoneNumber: string;
  belongsToCorporate: User;
}

// User Schema Definition
export const UserSchemaDefinition: SchemaDefinition<User> = {
  name: {
    type: String,
    minlength: 2,
    maxlength: 25,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  phoneNumber: {
    type: String,
    required: true,
  },
  password: { type: String, required: true },
  verified: { type: Boolean, required: true, default: false },
  roles: {
    type: [{ type: String, enum: Object.values(ROLES) }],
    validate: {
      validator: (roles: ROLES[]) => roles.length >= 1,
      message: "At least one role is required.",
    },
    required: true,
  },

  belongsToCorporate: { type: Schema.Types.ObjectId, ref: "User" },
};

// User Schema
const userSchema = new Schema(UserSchemaDefinition);
userSchema.set("timestamps", true);

// paginate with this plugin
userSchema.plugin(paginate);

// User Model
const UserModel = model<User, PaginateModel<User>>("User", userSchema);

export default UserModel;
